<html>
<head></head>
<body>

<form action="" method="get">
	Unesite prvi broj: <input name="broj1" type="number" > <br> <br>
	Unesite drugi broj: <input name="broj2" type="number" >
	<input type="submit" value="Izračunaj">
</form>

<?php	
function Average ($a, $b){
    $prosjek= ($a+$b)/2;
	echo $prosjek;
}

if(isset($_GET["broj1"]) && isset($_GET["broj2"])){
	$a=$_GET["broj1"];
	$b=$_GET["broj2"];
Average ($a,$b);
}
?>
	</body>
</html>