<html>
<head></head>
<body>

<form action="" method="get">
		Unesite JMBG:<input name="broj" type="number" >
		<input type="submit" value="Click here">
		</form>

<?php
if(isset($_GET["broj"])){
	$jmbg = $_GET["broj"];
	
$jmbglength=strlen((string)$jmbg);
if($jmbglength==13){
$dani = substr($jmbg, 0,2);
$mjesec = substr($jmbg, 2,2);
	if($dani<=31 && $dani >0 && $mjesec>0 && $mjesec <=12){
		echo "Dan rodenja: " . $dani . "<br>";
		echo "Mjesec rodenja: " . $mjesec . "<br>";
		}
	else{
		echo "JMBG nije tocan, provjerite jeste li dobro unijeli dan i mjesec";
		
		}
	$god = substr($jmbg, 4,3);
	if (($god>=900 && $god<=999) || ($god>=000 && $god<=017)){
		echo "Godina rodenja: 1", $god, "<br>";
		}
	else{
		echo "JMBG nije tocan, provjerite jeste li dobro unijeli godinu";
	}
	$regija = substr($jmbg, 7,2);
	 if($regija==15){
		echo "Regija rodenja: Mostar <br>";
		}
	 else{
		echo "JMBG nije tocan, provjerite jeste li dobro unijeli regiju";
		}
	$spol = substr($jmbg, 10,3);
	if($spol<499){
		echo "Spol: Muški <br>";
		}
	else{
		echo "Spol: Ženski <br>";
		}

}
	else{
		echo "JMBG nije tocan, niste unijeli 13 znakova";
		return false;
		}
}

?>
</body>
</html>