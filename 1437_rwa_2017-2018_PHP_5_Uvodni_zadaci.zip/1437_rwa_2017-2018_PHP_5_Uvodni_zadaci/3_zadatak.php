<html>
<head> </head>
<body>
<?php
$i;
$suma=0;
$i=1;
$suma=0;
while ($i<=100){
  $suma = $suma + $i;
  $i++;
}
echo "Suma prvih 100 prirodnih brojeva je: $suma";
?>
</body>
</html>