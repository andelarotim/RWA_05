<html>
<head> </head>
<body>
<?php
$i;
for ($i=1; $i<=20; $i++){
  echo "Broj $i ima kvadrat " . $i*$i ."<br>";
}
?>
</body>
</html>