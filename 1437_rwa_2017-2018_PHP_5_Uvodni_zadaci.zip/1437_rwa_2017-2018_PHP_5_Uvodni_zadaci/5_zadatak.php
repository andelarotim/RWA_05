<html>
<head> </head>
<body>

<?php
$i;
for ($i=100; $i<=999; $i++){
  if ($i%2==0)
  echo $i . "<br>";
}
?>

</body>
</html>