<html>
<head> </head>
<body>

<?php
$brojevi = array( 1, 22, 3, 4, 5, 99, 12, 49, 14, 23, 7);
$suma=0;
foreach ($brojevi as $x){
$suma=$suma+$x;
}
echo $suma;
?>

</body>
</html>