<html>
<head> </head>
<body>
<?php
$i;
for ($i=2; $i<=100; $i=$i+2){
  echo $i . "<br>";
}
?>
</body>
</html>