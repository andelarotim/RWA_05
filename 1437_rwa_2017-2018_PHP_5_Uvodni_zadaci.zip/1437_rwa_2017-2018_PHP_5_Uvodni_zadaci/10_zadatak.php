<html>
	<head>
	</head>
	
	<body>
		<form action="" method="get">
		Unesite sirinu pravokutnika:<input name="sirina" type="number"> <br> <br>
		Unesite duzinu pravokutnika:  <input name="duzina" type="number">
		<input type="submit" value="Izračunaj">
		</form>
		
		<?php
			if(isset($_GET["sirina"]) && isset($_GET["duzina"])){
				$a=$_GET["sirina"];
				$b=$_GET["duzina"];
				$pov_pravokutnik=$a*$b;
				echo "Povrsina pravokutnika sirine $a i duzine $b iznosi $pov_pravokutnik";
			}
		?>
	</body>
</html>