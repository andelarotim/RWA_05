<html>
<head> </head>
<body>

<?php
$i;
for ($i=10; $i<=99; $i++){
  if ($i%3==0 && $i%5==0 && $i%15==00)
  echo $i . "<br>";
}
?>

</body>
</html>