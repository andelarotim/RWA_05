<html>
<head> </head>
<body>

<?php
$grad = array(1995 => 54000, 1997 => 58810, 1998 => 62154, 2000 =>60124, 2002 => 63114); 
$i=0;
$suma=0;
$prosjek;
$max=$grad[1995];
foreach ($grad as $x){
  $i++;
  $suma=$suma+$x;
  if ($max<$x)
      $max=$x;     
}
$prosjek=$suma/$i;

echo "Prosjecni broj stanovnika kroz sve godine je $prosjek" . "<br>";
echo "Najvise stanovnika je bilo " . array_search($max,$grad) . " godine" . "<br>";
echo "Mjerenje se provodilo $i godina";

?>

</body>
</html>