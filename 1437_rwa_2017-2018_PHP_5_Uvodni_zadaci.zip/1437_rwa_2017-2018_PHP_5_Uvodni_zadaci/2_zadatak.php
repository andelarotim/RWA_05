<html>
<head> </head>
<body>
<?php
$i;
$suma=0;
for ($i=1; $i<=100; $i++){
  $suma= $suma + $i;
}
  echo "Suma prvih 100 prirodnih brojeva je: $suma";
?>
</body>
</html>