<html>
<head> </head>
<body>

<?php
function jeLiProst($broj){
if($broj==2)return 1;
for($i=2;$i<=$broj/2;$i++){
if($broj%$i==0)return 0;
}
return 1;
}
for($i=2;$i<100;$i++)
if(jeLiProst($i))echo"$i <br>";
?>

</body>
</html>
