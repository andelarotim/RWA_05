<?php
if (isset($_GET['broj'])){
$br=$_GET['broj'];
echo "Poslali ste broj: $br <br>";

if (isset($_GET['operacija1'])){
$rez=$br*$br;
echo "Operacija je: KVADRAT <br>";
echo "Rezultat je: $rez";
}
else if (isset($_GET['operacija2'])){
$rez=$br*$br*$br;
echo "Operacija je: KUB <br>";
echo "Rezultat je: $rez";
}

else{
	echo "Molimo unesite operaciju";
}
}
else{
	header ('Location: forma.html');
}

?>